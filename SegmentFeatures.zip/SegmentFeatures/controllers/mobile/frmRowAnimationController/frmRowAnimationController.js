define({ 
  	fromRowAnimationPostShow:function(){
      this.view.smsMessage.reFreshWithRowAnim();
    }
 });