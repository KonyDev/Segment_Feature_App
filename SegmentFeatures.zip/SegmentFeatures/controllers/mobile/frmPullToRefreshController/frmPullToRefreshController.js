define({ 
  	segmentOnPullCallback:function(){
      	alert("Segment Pull Triggered!!");
    },
  	frmPullToRefreshCallback:function(){
       this.view.segSampleProducts.onPull=this.segmentOnPullCallback;
    }
 });