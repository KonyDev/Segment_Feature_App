define({ 
  	lockSegments:true,
  	onClickLockSegments:function(){
    },
  	onSwitchSlide:function(eventobject){
      //alert("switch slide occured! "+this.view.switchLock.selectedIndex);
      if(this.view.switchLock.selectedIndex===1){
        	//alert("unlocked!!!");
        	this.view.segData1.height = "98%";
          	this.view.segData2.height = "98%";
            this.view.flxSeperator.height = "100%";
      }else if(this.view.switchLock.selectedIndex===0){
        	//alert("locked!!");
        	this.view.segData1.height = "190%";
          	this.view.segData2.height = "190%";
          	this.view.flxSeperator.height = "190%";
      	}
     	this.view.forceLayout();   
    }
 });