define({ 
	featureSelected:function(){
      	var formToBeNavigated = null;
     	switch(this.view.segFeatureOptions.selectedRowIndex[1]){
          case 0:	formToBeNavigated = "frmRowAnimation";
            		break;
          case 1:	formToBeNavigated = "frmExpandCollapse";
            		break;
          case 2:	formToBeNavigated = "frmSwipeToDelete";
            		break;
          case 3:	formToBeNavigated = "frmPullToRefresh";
            		break;
          case 4:	formToBeNavigated = "frmCoupledSegments";
            		break;
          default:
            		kony.print("You Shld not be here!!!");
            		return;   
        }
      	var ntf = new kony.mvc.Navigation(formToBeNavigated);
    	ntf.navigate();
    }
 });