define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Segment_df34f2ee6d1344f3a84af71d0c4b0579: function AS_Segment_df34f2ee6d1344f3a84af71d0c4b0579(eventobject, sectionNumber, rowNumber) {
        var self = this;
        this.featureSelected();
    }
});