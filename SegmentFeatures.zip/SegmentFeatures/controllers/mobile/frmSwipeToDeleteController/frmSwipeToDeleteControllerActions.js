define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_FlexContainer_g9ae00071531481296886c507f28e56b: function AS_FlexContainer_g9ae00071531481296886c507f28e56b(eventobject) {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmLanding");
        ntf.navigate();
    }
});