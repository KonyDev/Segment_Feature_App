define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_FlexContainer_ic9540b5ed1d414a95580dd807e835f6: function AS_FlexContainer_ic9540b5ed1d414a95580dd807e835f6(eventobject) {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmLanding");
        ntf.navigate();
    }
});