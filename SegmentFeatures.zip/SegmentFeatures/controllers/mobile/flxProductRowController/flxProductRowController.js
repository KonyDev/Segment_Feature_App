define({ 
		setSwipeGestureForProduct:function(){
          alert("inside template Conttroller!!!!");
        }	
 });