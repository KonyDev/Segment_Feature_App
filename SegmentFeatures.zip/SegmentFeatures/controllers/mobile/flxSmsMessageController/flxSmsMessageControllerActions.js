define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_FlexContainer_b8f44d27d7874ae5bf7df47b15904bae: function AS_FlexContainer_b8f44d27d7874ae5bf7df47b15904bae(eventobject, context) {
        var self = this;
        alert("clicked on mark read!!!");
    },
    AS_FlexContainer_bc5b68e343aa476481e8bc46e8a18a9a: function AS_FlexContainer_bc5b68e343aa476481e8bc46e8a18a9a(eventobject, context) {
        var self = this;
        this.onDeleteRow(eventobject, context);
    }
});