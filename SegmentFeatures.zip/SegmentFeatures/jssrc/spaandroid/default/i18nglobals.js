kony.globals["appid"] = "SegmentFeatures";
kony.globals["locales"] = [];