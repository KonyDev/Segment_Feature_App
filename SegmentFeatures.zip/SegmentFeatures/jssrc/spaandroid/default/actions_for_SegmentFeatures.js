//actions.js file 
function AS_FlexContainer_b167c3390a6d42908fc8ee84fcdf5650(eventobject) {
    var self = this;
    this.productListPreshow();
}

function AS_FlexContainer_g1769dd8deaa47f597705f406c91b7d5(eventobject) {
    var self = this;
    this.smsMsgPostShow();
}

function AS_Segment_g9cde260521841d5a2e2ec22c93ffdd6(eventobject, sectionNumber, rowNumber) {
    var self = this;
    this.productOnClick();
}