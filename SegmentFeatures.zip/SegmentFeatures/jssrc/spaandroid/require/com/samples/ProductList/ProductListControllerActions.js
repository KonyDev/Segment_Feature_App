define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Segment_g9cde260521841d5a2e2ec22c93ffdd6: function AS_Segment_g9cde260521841d5a2e2ec22c93ffdd6(eventobject, sectionNumber, rowNumber) {
        var self = this;
        this.productOnClick();
    },
    AS_FlexContainer_b167c3390a6d42908fc8ee84fcdf5650: function AS_FlexContainer_b167c3390a6d42908fc8ee84fcdf5650(eventobject) {
        var self = this;
        this.productListPreshow();
    }
});