//actions.js file 
function AS_Segment_g9cde260521841d5a2e2ec22c93ffdd6(eventobject, sectionNumber, rowNumber) {
    var self = this;
    this.productOnClick();
}