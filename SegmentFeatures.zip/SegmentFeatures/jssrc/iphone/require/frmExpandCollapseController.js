define({
    "AS_FlexContainer_ic9540b5ed1d414a95580dd807e835f6": function AS_FlexContainer_ic9540b5ed1d414a95580dd807e835f6(eventobject) {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmLanding");
        ntf.navigate();
    }
})