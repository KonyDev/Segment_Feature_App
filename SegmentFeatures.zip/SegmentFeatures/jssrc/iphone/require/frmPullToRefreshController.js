define({
    "segmentOnPullCallback": function() {
        alert("segment pull occured!!!!");
    },
    "frmPullToRefreshCallback": function() {
        this.view.segSampleProducts.onPull = this.segmentOnPullCallback;
        alert();
    },
    "AS_FlexContainer_hee0e46c0ceb40ed8ce18624746fa6af": function AS_FlexContainer_hee0e46c0ceb40ed8ce18624746fa6af(eventobject) {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmLanding");
        ntf.navigate();
    },
    "AS_Segment_be8c15ed1f1648e8a2a7e95985be5053": function AS_Segment_be8c15ed1f1648e8a2a7e95985be5053(eventobject) {
        var self = this;

        function SHOW_ALERT_ide_onPull_j529e9c7e3ca48f58e2c8c03fc99a07a_True() {}
        this.segmentOnPullCallback();
    },
    "AS_Form_c9249adf100941568ad5d3b9eb68c4dc": function AS_Form_c9249adf100941568ad5d3b9eb68c4dc(eventobject) {
        var self = this;
    }
})