define(function() {
    return {
        "properties": [],
        "apis": ["reFreshWithRowAnim", "setSmsData"],
        "events": []
    }
});