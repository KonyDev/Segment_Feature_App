define(function() {
    return {
        "properties": [],
        "apis": ["reFreshWithRowAnim"],
        "events": []
    }
});