define({
    "lockSegments": true,
    "onClickLockSegments": function() {
        if (this.lockSegments) {
            this.view.segData1.height = "98%";
            this.view.segData2.height = "98%";
            this.view.flxSeperator.height = "100%";
            this.view.imgLock.src = "switchoffgray.png";
            this.lockSegments = false;
        } else {
            this.view.segData1.height = "210%";
            this.view.segData2.height = "210%";
            this.view.flxSeperator.height = "210%";
            this.view.imgLock.src = "swichongreen.png";
            this.lockSegments = true;
        }
        this.view.forceLayout();
    },
    "AS_FlexContainer_b0d6dbb0482c476999ce43603373fa5d": function AS_FlexContainer_b0d6dbb0482c476999ce43603373fa5d(eventobject) {
        var self = this;
        this.onClickLockSegments();
    },
    "AS_FlexContainer_gf34945cb6d648fa913f9895bb3adc0d": function AS_FlexContainer_gf34945cb6d648fa913f9895bb3adc0d(eventobject) {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmLanding");
        ntf.navigate();
    }
})