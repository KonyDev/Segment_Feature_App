define({
    "__SMS_DATA": undefined,
    "onNavigate": function() {
        if (this.__SMS_DATA === undefined) {
            //   	this.__SMS_DATA = this.view.smsMessage.smsdata;
        } else {
            //this.view.smsMessage.setSmsData(this.__SMS_DATA);
        }
    },
    "AS_FlexContainer_g9ae00071531481296886c507f28e56b": function AS_FlexContainer_g9ae00071531481296886c507f28e56b(eventobject) {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmLanding");
        ntf.navigate();
    }
})