define({
    "AS_FlexContainer_g9ae00071531481296886c507f28e56b": function AS_FlexContainer_g9ae00071531481296886c507f28e56b(eventobject) {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmLanding");
        ntf.navigate();
    }
})