var SSOFFI={};
SSOFFI.saveToken= function(item,key){};
SSOFFI.getToken= function(key){};
SSOFFI.deleteToken= function(key){};
