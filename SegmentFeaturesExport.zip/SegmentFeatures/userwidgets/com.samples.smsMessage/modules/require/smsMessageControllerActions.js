define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** postShow defined for smsMessage **/
    AS_FlexContainer_g1769dd8deaa47f597705f406c91b7d5: function AS_FlexContainer_g1769dd8deaa47f597705f406c91b7d5(eventobject) {
        var self = this;
        this.smsMsgPostShow();
    }
});