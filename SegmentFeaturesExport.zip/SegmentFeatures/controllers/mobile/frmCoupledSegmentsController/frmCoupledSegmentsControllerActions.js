define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onSlide defined for switchLock **/
    AS_Switch_e131ad00c54d4b928f2960775e9d5768: function AS_Switch_e131ad00c54d4b928f2960775e9d5768(eventobject) {
        var self = this;
        this.onSwitchSlide(eventobject);
    },
    /** onClick defined for flxBack **/
    AS_FlexContainer_gf34945cb6d648fa913f9895bb3adc0d: function AS_FlexContainer_gf34945cb6d648fa913f9895bb3adc0d(eventobject) {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmLanding");
        ntf.navigate();
    }
});