define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for flxBack **/
    AS_FlexContainer_hee0e46c0ceb40ed8ce18624746fa6af: function AS_FlexContainer_hee0e46c0ceb40ed8ce18624746fa6af(eventobject) {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmLanding");
        ntf.navigate();
    },
    /** onPull defined for segSampleProducts **/
    AS_Segment_aa850326889c445180667ade3962d78b: function AS_Segment_aa850326889c445180667ade3962d78b(eventobject) {
        var self = this;
        this.segmentOnPullCallback();
    },
    /** postShow defined for frmPullToRefresh **/
    AS_Form_c9249adf100941568ad5d3b9eb68c4dc: function AS_Form_c9249adf100941568ad5d3b9eb68c4dc(eventobject) {
        var self = this;
        this.frmPullToRefreshCallback();
    }
});