define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for flxMarkRead **/
    AS_FlexContainer_b28bec4704274cf19270b98151693284: function AS_FlexContainer_b28bec4704274cf19270b98151693284(eventobject, context) {
        var self = this;
        alert("clicked on mark read!!!");
    },
    /** onClick defined for flxDelRow **/
    AS_FlexContainer_g3b73636d7ac4453b29f45819c194fa0: function AS_FlexContainer_g3b73636d7ac4453b29f45819c194fa0(eventobject, context) {
        var self = this;
        this.onDeleteRow(eventobject, context);
    }
});