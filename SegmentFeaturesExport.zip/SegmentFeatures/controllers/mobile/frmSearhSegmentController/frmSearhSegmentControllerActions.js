define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for flxBack **/
    AS_FlexContainer_h623a49e06224201a4592ead0154e721: function AS_FlexContainer_h623a49e06224201a4592ead0154e721(eventobject) {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmLanding");
        ntf.navigate();
    },
    /** onClick defined for btnSearch **/
    AS_Button_a5f473cfacf449a6a75d71c8a7a724ab: function AS_Button_a5f473cfacf449a6a75d71c8a7a724ab(eventobject) {
        var self = this;
        this.searchforString(this.view.txtSearchString.text);
    },
    /** onClick defined for btnClearSearch **/
    AS_Button_d84cbc5d342c457d82d342537ceb908f: function AS_Button_d84cbc5d342c457d82d342537ceb908f(eventobject) {
        var self = this;
        this.clearSearch();
    },
    /** postShow defined for frmSearhSegment **/
    AS_Form_f754dccb54d243e887c45cc0ffd2b228: function AS_Form_f754dccb54d243e887c45cc0ffd2b228(eventobject) {
        var self = this;
        this.fromRowAnimationPostShow();
    }
});